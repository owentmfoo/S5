from S5.nonosquare import why
import S5.Tecplot as Tecplot
import S5.Tecplot as tecplot # to offer an option for those who wish to follow PEP8
